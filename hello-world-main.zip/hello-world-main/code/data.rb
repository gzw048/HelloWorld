# To run this code, be sure your current working directory
# is the same as where this file is located and then run:
# ruby data.rb

# In Ruby, there are different *types* of data:

# - Numbers

# - Perform simple math with numbers

# - Strings

# - Combine strings together

# - Variables

# - Combine strings and variables
