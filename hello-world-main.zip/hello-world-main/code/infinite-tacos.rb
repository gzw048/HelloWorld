loop do
  puts "Tacos!"
end